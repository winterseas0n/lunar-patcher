@echo off
setlocal
title Restore Lunar Client
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lunar-Offline.ps1" -Restore
if errorlevel 1 echo Restore failed. Read the error above.
pause