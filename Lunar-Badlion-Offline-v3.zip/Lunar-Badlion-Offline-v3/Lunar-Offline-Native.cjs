// Version-specific offline-profile support for the inspected Badlion native module.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const ORIGINAL='5114de238e3d310401f085d3025f9845e58c9d96bd1667ae7d22755b69ba67b1';
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const align=(n,a)=>Math.ceil(n/a)*a;
function build(original,username,uuid){
  if(digest(original)!==ORIGINAL)throw Error('Unsupported Badlion launcher.node build');
  if(!/^[A-Za-z0-9_]{3,16}$/.test(username)||!/^[0-9a-f]{32}$/i.test(uuid))throw Error('Invalid offline identity');
  const pe=original.readUInt32LE(0x3c),optional=pe+24,count=original.readUInt16LE(pe+6),table=optional+original.readUInt16LE(pe+20);
  if(original.readUInt16LE(optional)!==0x20b)throw Error('Expected x64 native module');
  const fileAlignment=original.readUInt32LE(optional+36),sectionAlignment=original.readUInt32LE(optional+32);
  if(table+40*(count+1)>original.readUInt32LE(optional+60))throw Error('No room for native patch section');
  let endRva=0;
  function offset(rva){
    for(let i=0;i<count;i++){
      const p=table+40*i,va=original.readUInt32LE(p+12),rawSize=original.readUInt32LE(p+16);
      if(rva>=va&&rva<va+rawSize)return original.readUInt32LE(p+20)+rva-va;
    }throw Error('Native RVA outside file');
  }
  for(let i=0;i<count;i++){
    const p=table+40*i;
    endRva=Math.max(endRva,original.readUInt32LE(p+12)+Math.max(original.readUInt32LE(p+8),original.readUInt32LE(p+16)));
  }
  const rva=align(endRva,sectionAlignment),raw=align(original.length,fileAlignment),entry=0x1149b0;
  const saved=original.subarray(offset(entry),offset(entry)+5);
  if(!saved.equals(Buffer.from('4055535657','hex')))throw Error('Native prologue mismatch');
  const code=[],fixups=[],labels=new Map();
  const emit=(...bytes)=>code.push(...bytes);
  const hex=s=>emit(...Buffer.from(s.replaceAll(' ',''),'hex'));
  function rel(opcode,target){hex(opcode);const p=code.length;emit(0,0,0,0);fixups.push({p,target});}
  const label=name=>labels.set(name,code.length);
  hex('4883ec58 48894c2420 4889542428 4c89442430 4889d1');
  rel('e8',0x14530); // CkString::getUtf8
  hex('4885c0');rel('0f84','fallback');
  const marker=Buffer.from('lunar-offline-v1');
  hex('49ba');emit(...marker.subarray(0,8));hex('4c3910');rel('0f85','fallback');
  hex('49ba');emit(...marker.subarray(8,16));hex('4c395008');rel('0f85','fallback');
  hex('80781000');rel('0f85','fallback');
  hex('488b4c2430');rel('488d15','claims');
  rel('e8',0x1e2390); // CkJsonObject::Load
  hex('4883c458 c3');
  label('fallback');
  hex('488b4c2420 488b542428 4c8b442430 4883c458');emit(...saved);
  rel('e9',entry+5);
  label('claims');
  const dashed=uuid.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/,'$1-$2-$3-$4-$5');
  emit(...Buffer.from(JSON.stringify({username,uuid:dashed})+'\0'));
  const section=Buffer.from(code);
  for(const {p,target}of fixups){
    const targetRva=typeof target==='number'?target:rva+labels.get(target);
    section.writeInt32LE(targetRva-(rva+p+4),p);
  }
  const rawSize=align(section.length,fileAlignment);
  const result=Buffer.alloc(raw+rawSize);original.copy(result);section.copy(result,raw);
  const header=table+count*40;
  result.fill(0,header,header+40);result.write('.loff',header,'ascii');
  result.writeUInt32LE(section.length,header+8);result.writeUInt32LE(rva,header+12);
  result.writeUInt32LE(rawSize,header+16);result.writeUInt32LE(raw,header+20);
  result.writeUInt32LE(0x60000020,header+36); // code, execute, read
  result.writeUInt16LE(count+1,pe+6);
  result.writeUInt32LE(align(rva+section.length,sectionAlignment),optional+56);
  result.writeUInt32LE(original.readUInt32LE(optional+4)+rawSize,optional+4);
  result.writeUInt32LE(0,optional+64); // changed image checksum
  // The modified image has no valid Authenticode signature.
  result.fill(0,optional+112+4*8,optional+112+4*8+8);
  const entryOffset=offset(entry);result[entryOffset]=0xe9;
  result.writeInt32LE(rva-entry-5,entryOffset+1);
  return result;
}
function patchNative(account,exe=process.execPath){
  const file=path.join(path.dirname(exe),'native-modules','launcher.node');
  const backup=file+'.original-offline-v3';
  const current=fs.readFileSync(file);
  let original;
  if(digest(current)===ORIGINAL)original=current;
  else if(fs.existsSync(backup)&&digest(fs.readFileSync(backup))===ORIGINAL)original=fs.readFileSync(backup);
  else throw Error('Unrecognized Badlion native module; no changes applied');
  if(!account||account.legacy!==true||account.accessToken!=='lunar-offline-v1'){
    if(!current.equals(original))fs.writeFileSync(file,original);
    return;
  }
  const patched=build(original,account.minecraftProfile.name,account.minecraftProfile.id);
  if(current.equals(patched))return;
  if(!current.equals(original))throw Error('Different offline identity already patched; restart Lunar before changing nicknames');
  if(!fs.existsSync(backup))fs.writeFileSync(backup,original,{flag:'wx'});
  else if(digest(fs.readFileSync(backup))!==ORIGINAL)throw Error('Native module backup mismatch');
  fs.writeFileSync(file,patched);
}
module.exports={build,patchNative};
if(require.main===module){
  const [input,output,username,uuid]=process.argv.slice(2);
  fs.writeFileSync(output,build(fs.readFileSync(input),username,uuid));
  console.log('Built native offline-profile test module');
}
