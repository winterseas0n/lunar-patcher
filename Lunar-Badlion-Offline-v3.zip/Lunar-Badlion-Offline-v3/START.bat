@echo off
setlocal
title Lunar + Badlion Offline Setup v3
if not exist "%~dp0Lunar-Offline.ps1" goto missing
if not exist "%~dp0Lunar-Offline-Native.cjs" goto missing
echo Close Lunar Client, including its tray icon, and Minecraft.
echo Enter YOUR nickname when asked. The launcher path is detected automatically.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lunar-Offline.ps1" -Restart
if errorlevel 1 (
  echo.
  echo Setup failed. Read the error above.
  pause
  exit /b 1
)
echo.
echo Done. Select Lunar or Badlion in the launcher and click Launch Game.
pause
exit /b 0
:missing
echo Extract ALL files from the ZIP into one folder first.
pause
exit /b 1