@echo off
setlocal
title Lunar Offline Setup
if not exist "%~dp0Lunar-Offline.ps1" (
  echo Extract ALL files from the ZIP into one folder first.
  pause
  exit /b 1
)
echo Close Lunar Client and Minecraft before continuing.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Lunar-Offline.ps1" -Restart
if errorlevel 1 (
  echo.
  echo Setup failed. Read the error above.
  pause
  exit /b 1
)
echo.
echo Launcher patched. Select your profile and try launching Minecraft.
pause
