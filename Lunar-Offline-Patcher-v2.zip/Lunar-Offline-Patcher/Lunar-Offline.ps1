param(
    [ValidatePattern('^[A-Za-z0-9_]{3,16}$')][string]$Username,
    [string]$Executable,
    [string]$DataDirectory = (Join-Path $env:USERPROFILE '.lunarclient'),
    [switch]$BuildOnly,
    [string]$OutputDirectory = (Join-Path $PSScriptRoot 'build'),
    [switch]$Restore,
    [switch]$Restart
)
$ErrorActionPreference = 'Stop'
$originalHash = '506574F17A6B7AEB5A13FE5F53FC83329FA705141505DDE30EC88E00AA03A9F4'
$previousPatchedHash = '8388F628C76FA6AF4C540DEB8B02AF848A6603E7884E0D59C29144304CA7FB53'
$previousPatchedHeaderHash = 'c29c92c0fb473a683ad1f4368fbc024fcb0279b40afaeb5ca0f26f96c54efed3'
$originalExeHash = 'E21D5AD61A3CAEC8E25948A52F3A0157B9E875EF6CD9A47CD1EE874A7E58F5E6'
$exeHashOffset = 233943951
$originalHeaderHash = '3aec89f32ef58ca0533103d25000c8bbd6a10d1f941145f1e79a4e82305aa025'
$utf8 = [Text.UTF8Encoding]::new($false)
function Hash-Bytes([byte[]]$Data) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Data))).Replace('-', '').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Replace-Unique([string]$Text, [string]$Old, [string]$New) {
    $index = $Text.IndexOf($Old, [StringComparison]::Ordinal)
    if ($index -lt 0 -or $Text.IndexOf($Old, $index + $Old.Length, [StringComparison]::Ordinal) -ge 0) {
        throw 'Application signature mismatch. Nothing was patched.'
    }
    return $Text.Substring(0, $index) + $New + $Text.Substring($index + $Old.Length)
}
function Get-CanonicalExeHash([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    $buffer = [byte[]]::new(65536)
    $expected = [Text.Encoding]::ASCII.GetBytes($originalHeaderHash)
    try {
        $position = 0L
        while (($count = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            $overlapStart = [Math]::Max($position, $exeHashOffset)
            $overlapEnd = [Math]::Min($position + $count, $exeHashOffset + 64)
            if ($overlapEnd -gt $overlapStart) {
                [Array]::Copy($expected, [int]($overlapStart - $exeHashOffset), $buffer, [int]($overlapStart - $position), [int]($overlapEnd - $overlapStart))
            }
            $null = $sha.TransformBlock($buffer, 0, $count, $buffer, 0)
            $position += $count
        }
        $null = $sha.TransformFinalBlock([byte[]]@(), 0, 0)
        return ([BitConverter]::ToString($sha.Hash)).Replace('-', '')
    } finally { $stream.Dispose(); $sha.Dispose() }
}
if (!$Executable) {
    $candidates = @(
        @(Get-Process 'Lunar Client' -ErrorAction SilentlyContinue | ForEach-Object { $_.Path })
        "$env:LOCALAPPDATA\Programs\Lunar Client\Lunar Client.exe"
        "$env:ProgramFiles\Lunar Client\Lunar Client.exe"
        (Join-Path $PSScriptRoot 'Lunar Client.exe')
    )
    foreach ($registry in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')) {
        foreach ($entry in @(Get-ItemProperty $registry -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like '*Lunar*Client*' })) {
            if ($entry.InstallLocation) { $candidates += Join-Path $entry.InstallLocation 'Lunar Client.exe' }
            if ($entry.DisplayIcon) { $candidates += Join-Path (Split-Path ($entry.DisplayIcon.Trim('"')) -Parent) 'Lunar Client.exe' }
        }
    }
    $found = @($candidates | Where-Object { $_ -and (Test-Path -LiteralPath $_ -PathType Leaf) } | ForEach-Object { (Get-Item -LiteralPath $_).FullName } | Select-Object -Unique)
    if ($found.Count -eq 1) { $Executable = $found[0] }
    elseif ($found.Count -gt 1) {
        for ($i = 0; $i -lt $found.Count; $i++) { Write-Host "$($i + 1). $($found[$i])" }
        do { $choice = Read-Host 'Choose installation number'; $number = 0 }
        until ([int]::TryParse($choice, [ref]$number) -and $number -ge 1 -and $number -le $found.Count)
        $Executable = $found[$number - 1]
    } else { $Executable = (Read-Host 'Paste the full path to Lunar Client.exe').Trim().Trim('"') }
}
$Executable = [IO.Path]::GetFullPath($Executable)
$asar = Join-Path (Split-Path $Executable -Parent) 'resources\app.asar'
$original = "$asar.original-3.7.24-ow"
$originalExe = "$Executable.original-3.7.24-ow"
if (!(Test-Path -LiteralPath $asar)) { throw 'Lunar resources/app.asar not found.' }
Write-Host "Lunar: $Executable"
if ($Restore) {
    if (Get-Process 'Lunar Client' -ErrorAction SilentlyContinue) { throw 'Close Lunar Client including its tray icon first.' }
    if (!(Test-Path -LiteralPath $original) -or (Get-FileHash -LiteralPath $original).Hash -ne $originalHash) { throw 'Verified original backup not found.' }
    if (!(Test-Path -LiteralPath $originalExe) -or (Get-FileHash -LiteralPath $originalExe).Hash -ne $originalExeHash) { throw 'Verified EXE backup not found.' }
    Copy-Item -LiteralPath $original -Destination $asar -Force
    Copy-Item -LiteralPath $originalExe -Destination $Executable -Force
    Write-Host 'Original launcher restored. Offline accounts remain in accounts.json.'
    return
}
if ((Get-FileHash -LiteralPath $asar).Hash -eq $originalHash) { $sourceFile = $asar }
elseif ((Test-Path -LiteralPath $original) -and (Get-FileHash -LiteralPath $original).Hash -eq $originalHash) { $sourceFile = $original }
else { throw 'Unsupported build. This patch supports only the inspected Lunar 3.7.24-ow archive.' }
$bytes = [IO.File]::ReadAllBytes($sourceFile)
$headerLength = [BitConverter]::ToUInt32($bytes, 12)
$headerText = $utf8.GetString($bytes, 16, $headerLength)
$header = $headerText | ConvertFrom-Json
$entry = $header.files.'dist-electron'.files.electron.files.'main.js'
if (!$entry -or $entry.unpacked -or $entry.integrity.algorithm -ne 'SHA256') { throw 'Unsupported ASAR structure.' }
$base = 8 + [BitConverter]::ToUInt32($bytes, 4)
$offset = $base + [int]$entry.offset
$oldMain = [byte[]]::new([int]$entry.size)
[Array]::Copy($bytes, $offset, $oldMain, 0, $oldMain.Length)
if ((Hash-Bytes $oldMain) -ne $entry.integrity.hash) { throw 'Original main.js checksum mismatch.' }
$source = $utf8.GetString($oldMain)
$start = $source.IndexOf('async initAuthInternal(e,t){', [StringComparison]::Ordinal)
$end = $source.IndexOf('async refreshAccount(e){', $start, [StringComparison]::Ordinal)
if ($start -lt 0 -or $end -lt 0) { throw 'Authentication method signature mismatch.' }
$method = $source.Substring($start, $end - $start)
$hook = 'try{LR.info(`Validating account ${r.minecraftProfile.name} owns Minecraft...`);'
$guard = 'if(r.legacy===!0&&r.accessToken==="lunar-offline-v1"){r.accessTokenExpiresAt=new Date(Date.now()+864e5).toISOString();r.refreshToken="lunar-offline-v1";let q=await VR();q.accounts[r.localId]=r;await HR(q);$.getModule(`assetserver`)?.getClient()?.close();fo(`account.guest`,!0);LR.info("LunarOffline v2: local offline profile enabled");Z.store.dispatch(bAe({uuid:r.minecraftProfile.id,invalid:!1}));Z.store.dispatch(kW({uuid:r.minecraftProfile.id,loading:!1}));return}'
# Shorten diagnostics inside this method so the archive entry keeps its exact size.
$method = Replace-Unique $method $hook ($guard + $hook)
$method = [regex]::Replace($method, 'LR\.info\(`[^`]{45,}`\)', 'LR.info(`Auth step`)')
$patchedSource = $source.Substring(0, $start) + $method + $source.Substring($end)
$encoded = $utf8.GetBytes($patchedSource)
if ($encoded.Length -gt $oldMain.Length) { throw 'Patched script exceeds the original ASAR entry size.' }
$newMain = [byte[]]::new($oldMain.Length)
for ($i = 0; $i -lt $newMain.Length; $i++) { $newMain[$i] = 32 }
[Array]::Copy($encoded, $newMain, $encoded.Length)
$newHeaderText = Replace-Unique $headerText $entry.integrity.hash (Hash-Bytes $newMain)
$blockSize = [int]$entry.integrity.blockSize
if ($blockSize -le 0) { throw 'Invalid ASAR integrity block size.' }
for ($block = 0; $block -lt $entry.integrity.blocks.Count; $block++) {
    $blockOffset = $block * $blockSize
    $length = [Math]::Min($blockSize, $newMain.Length - $blockOffset)
    $chunk = [byte[]]::new($length)
    [Array]::Copy($newMain, $blockOffset, $chunk, 0, $length)
    $newHeaderText = Replace-Unique $newHeaderText $entry.integrity.blocks[$block] (Hash-Bytes $chunk)
}
$newHeader = $utf8.GetBytes($newHeaderText)
if ($newHeader.Length -ne $headerLength) { throw 'ASAR header size changed unexpectedly.' }
[Array]::Copy($newHeader, 0, $bytes, 16, $newHeader.Length)
[Array]::Copy($newMain, 0, $bytes, $offset, $newMain.Length)
$patchedHash = (Hash-Bytes $bytes).ToUpperInvariant()
$patchedHeaderHash = Hash-Bytes $newHeader
if ((Get-CanonicalExeHash $Executable) -ne $originalExeHash) { throw 'Unsupported EXE build or unexpected EXE modifications.' }
$exeReader = [IO.File]::OpenRead($Executable)
try {
    $null = $exeReader.Seek($exeHashOffset, [IO.SeekOrigin]::Begin)
    $currentHeaderHashBytes = [byte[]]::new(64)
    if ($exeReader.Read($currentHeaderHashBytes, 0, 64) -ne 64) { throw 'EXE checksum resource is truncated.' }
    $currentHeaderHash = [Text.Encoding]::ASCII.GetString($currentHeaderHashBytes)
} finally { $exeReader.Dispose() }
if ($currentHeaderHash -ne $originalHeaderHash -and $currentHeaderHash -ne $patchedHeaderHash -and $currentHeaderHash -ne $previousPatchedHeaderHash) { throw 'EXE archive checksum resource is unexpected.' }
$installedHash = (Get-FileHash -LiteralPath $asar).Hash
if ($installedHash -ne $originalHash -and $installedHash -ne $patchedHash -and $installedHash -ne $previousPatchedHash) { throw 'Installed archive has unexpected modifications. Refusing to overwrite it.' }
if ($BuildOnly) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    [IO.File]::WriteAllBytes((Join-Path $OutputDirectory 'app.asar'), $bytes)
    [IO.File]::WriteAllBytes((Join-Path $OutputDirectory 'main.js'), $newMain)
    Write-Host "Build-only OK. Patched SHA256: $patchedHash"
    return
}
if (!$Username) {
    do { $Username = Read-Host 'Your nickname (3-16 letters A-Z, digits or underscore)' }
    until ($Username -match '^[A-Za-z0-9_]{3,16}$')
}
$processes = @(Get-Process 'Lunar Client' -ErrorAction SilentlyContinue)
foreach ($process in $processes) { if ($process.MainWindowHandle -ne 0) { $null = $process.CloseMainWindow() } }
if (Get-Process 'Lunar Client' -ErrorAction SilentlyContinue) {
    $null = Read-Host 'Exit Lunar from its tray icon, then press Enter (close the game first)'
    if (Get-Process 'Lunar Client' -ErrorAction SilentlyContinue) { throw 'Lunar is still running. No changes were applied.' }
}
$accountDirectory = Join-Path $DataDirectory 'settings\game'
$accountFile = Join-Path $accountDirectory 'accounts.json'
$accountRoot = [pscustomobject]@{ accounts = [pscustomobject]@{} }
if (Test-Path -LiteralPath $accountFile) {
    $accountRoot = Get-Content -LiteralPath $accountFile -Raw | ConvertFrom-Json
    if (!$accountRoot.accounts -or $accountRoot.accounts -is [array] -or $accountRoot.accounts -isnot [pscustomobject]) { throw 'Unsupported accounts.json. Existing accounts were not modified.' }
}
$md5 = [Security.Cryptography.MD5]::Create()
try { $digest = $md5.ComputeHash($utf8.GetBytes("OfflinePlayer:$Username")) } finally { $md5.Dispose() }
$digest[6] = ($digest[6] -band 15) -bor 48
$digest[8] = ($digest[8] -band 63) -bor 128
$uuid = ([BitConverter]::ToString($digest)).Replace('-', '').ToLowerInvariant()
$localId = "offline-$uuid"
$account = [pscustomobject]@{
    accessToken = 'lunar-offline-v1'; accessTokenExpiresAt = [DateTime]::UtcNow.AddDays(1).ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    refreshToken = 'lunar-offline-v1'
    localId = $localId; remoteId = '0'; type = 'Xbox'; username = $Username
    eligibleForMigration = $false; hasMultipleProfiles = $false; legacy = $true
    persistent = $true; userProperties = @(); minecraftProfile = @{ id = $uuid; name = $Username }
}
$accountRoot.accounts | Add-Member -NotePropertyName $localId -NotePropertyValue $account -Force
$accountRoot | Add-Member -NotePropertyName activeAccountLocalId -NotePropertyValue $localId -Force
$accountJson = $accountRoot | ConvertTo-Json -Depth 100
$null = $accountJson | ConvertFrom-Json
if (!(Test-Path -LiteralPath $original)) { Copy-Item -LiteralPath $asar -Destination $original }
elseif ((Get-FileHash -LiteralPath $original).Hash -ne $originalHash) { throw 'Unexpected original backup.' }
if (!(Test-Path -LiteralPath $originalExe)) {
    if ((Get-FileHash -LiteralPath $Executable).Hash -ne $originalExeHash) { throw 'Original EXE backup missing.' }
    Copy-Item -LiteralPath $Executable -Destination $originalExe
} elseif ((Get-FileHash -LiteralPath $originalExe).Hash -ne $originalExeHash) { throw 'Unexpected EXE backup.' }
$stamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff')
New-Item -ItemType Directory -Path $accountDirectory -Force | Out-Null
if (Test-Path -LiteralPath $accountFile) { Copy-Item -LiteralPath $accountFile -Destination "$accountFile.backup-$stamp" }
if ($installedHash -ne $patchedHash) {
    $temporary = "$asar.$stamp.tmp"
    [IO.File]::WriteAllBytes($temporary, $bytes)
    [IO.File]::Replace($temporary, $asar, "$asar.previous-$stamp")
}
if ($currentHeaderHash -ne $patchedHeaderHash) {
    $exeWriter = [IO.File]::Open($Executable, [IO.FileMode]::Open, [IO.FileAccess]::Write, [IO.FileShare]::None)
    try {
        $null = $exeWriter.Seek($exeHashOffset, [IO.SeekOrigin]::Begin)
        $resourceBytes = [Text.Encoding]::ASCII.GetBytes($patchedHeaderHash)
        $exeWriter.Write($resourceBytes, 0, $resourceBytes.Length)
        $exeWriter.Flush()
    } catch {
        Copy-Item -LiteralPath $original -Destination $asar -Force
        throw
    } finally { $exeWriter.Dispose() }
}
$accountTemporary = "$accountFile.$stamp.tmp"
[IO.File]::WriteAllText($accountTemporary, $accountJson, $utf8)
if (Test-Path -LiteralPath $accountFile) { [IO.File]::Replace($accountTemporary, $accountFile, "$accountFile.previous-$stamp") }
else { [IO.File]::Move($accountTemporary, $accountFile) }
Write-Host "Applied. Offline nickname: $Username"
if ($Restart) { Start-Process -FilePath $Executable -WindowStyle Hidden }
